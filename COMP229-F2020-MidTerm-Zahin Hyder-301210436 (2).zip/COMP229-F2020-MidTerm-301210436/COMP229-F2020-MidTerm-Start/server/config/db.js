module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb+srv://centennialcollege:<password>@cluster0.fchlso0.mongodb.net/?retryWrites=true&w=majority"
};
